// Placeholder FirebaseUtils.kt — original implementation should be placed here
